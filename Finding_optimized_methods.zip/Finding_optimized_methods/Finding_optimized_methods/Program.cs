﻿using BenchmarkDotNet.Running;
using System;
using BenchmarkDotNet.Attributes;

namespace Finding_optimized_methods
{
    class Program
    {
        static void Main(string[] args)
        {

            var benchRunner = BenchmarkRunner.Run<StringLoops>();
            Console.ReadLine();

        }
    }
}
