﻿using System;
using System.Collections.Generic;
using System.Text;
using BenchmarkDotNet.Attributes;

namespace Finding_optimized_methods
{
    public class StringLoops
    {

        public string mystring = "Howdypartner";

        [Benchmark]
        public char ForLoop()
        {

            for (int i = 0; i < this.mystring.Length; i++)
            {
                return this.mystring[i];
            }
            return ',';
        }

        [Benchmark]
        public char ForEachLoop()
        {

            foreach (char value in this.mystring)
            {
                return value;
            }
            return ',';
        }

        [Benchmark]
        public char WhileLoop()
        {

            var i = 0;

            while (i < this.mystring.Length)
            {

                var temp = this.mystring[i];
                i++;
                return temp;
            }

            return ',';
        }

        [Benchmark]
        public char DoWhileLoop()
        {

            var i = 0;

            do
            {
                var temp = this.mystring[i];
                i++;
                return temp;

            } while (i < this.mystring.Length);

            return ',';
        }   


    }
}
